(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[95],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/qbepnhix.js":
/*!***********************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/qbepnhix.js ***!
  \***********************************************************/
/*! exports provided: IonSlide */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonSlide", function() { return Slide; });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 * Built with http://stenciljs.com
 */
var Slide=function(){function e(){}return e.prototype.hostData=function(){return{class:{"slide-zoom":!0,"swiper-slide":!0}}},Object.defineProperty(e,"is",{get:function(){return"ion-slide"},enumerable:!0,configurable:!0}),Object.defineProperty(e,"style",{get:function(){return"ion-slide{display:block;width:100%;height:100%}.slide-zoom{display:block;width:100%;text-align:center}.swiper-slide{display:-webkit-box;display:-ms-flexbox;display:flex;position:relative;-ms-flex-negative:0;flex-shrink:0;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;width:100%;height:100%;font-size:18px;text-align:center;-webkit-box-sizing:border-box;box-sizing:border-box}.swiper-slide img{width:auto;max-width:100%;height:auto;max-height:100%}"},enumerable:!0,configurable:!0}),e}();

/***/ })

}]);
//# sourceMappingURL=95.js.map